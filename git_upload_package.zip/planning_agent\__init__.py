"""Planning document generator package."""
